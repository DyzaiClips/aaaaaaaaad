<?php

//aqui cal incloure el model de tasques
header('Location: ./view/app_view.php');

?>