<?php

//implmentar la logica per afeir una tasca al model
//ha de redirigir al app_view