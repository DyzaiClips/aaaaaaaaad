<?php




header("../view/app_view.php")
//implementar la logica per eliminar tasques
//ha de redirigir al app_view