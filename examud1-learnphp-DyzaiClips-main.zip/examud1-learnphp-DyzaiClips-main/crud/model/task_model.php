<?php

$tasks = [
   [
      "id" => 0,
      "nom" => "First to do admin",
      "descripcio" => "He de fer una tasca 1",
   ],
   [
      "id" => 1,
      "nom" => "Second to do admin",
      "descripcio" => "He de fer una altra tasca 2 ",
   ],
   [
      "id" => 2,
      "nom" => "First to do Raquel",
      "descripcio" => "He de fer una 1 ",
   ],
   [
      "id" => 3,
      "nom" => "Second to do raquel",
      "descripcio" => "He de fer una altra tasca 2",
   ],
   [
      "id" => 4,
      "nom" => "Second to do admin",
      "descripcio" => "He de fer una altra tasca 3 ",
   ],
   [
      "id" => 5,
      "nom" => "First to do Raquel",
      "descripcio" => "He de fer una tasca 3 ",
   ],
   [
      "id" => 6,
      "nom" => "Second to do raquel",
      "descripcio" => "He de fer una altra tasca 4",
   ],
   [
      "id" => 7,
      "nom" => "First to do admin",
      "descripcio" => "He de fer una tasca ",
   ],
   [
      "id" => 8,
      "nom" => "Second to do admin",
      "descripcio" => "He de fer una altra tasca dsafasd sdfafasd afdsafsa asdfa sd asdfasd f asdf ",
   ],
   [
      "id" => 9,
      "nom" => "First to do Raquel",
      "descripcio" => "He de fer una tasca dfsad sadf sadf asd fsadf asd fsda ",
   ],
   [
      "id" => 10,
      "nom" => "Second to do raquel",
      "descripcio" => "He de fer una altra tasca",
   ],
   [
      "id" => 11,
      "nom" => "Second to do admin",
      "descripcio" => "He de fer una altra tasca dsafasd sdfafasd afdsafsa asdfa sd asdfasd f asdf ",
   ],
   [
      "id" => 12,
      "nom" => "First to do Raquel",
      "descripcio" => "He de fer una tasca dfsad sadf sadf asd fsadf asd fsda ",
   ],
   [
      "id" => 13,
      "nom" => "Second to do raquel",
      "descripcio" => "He de fer una altra tasca",
   ]
];

$_SESSION['tasks'] = $tasks;