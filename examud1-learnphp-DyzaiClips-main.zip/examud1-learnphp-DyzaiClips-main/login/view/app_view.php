<?php
//en aquesta part del codi cal carregar la template de la navbar
include('../template/navbar_app.php');
?>

<div class="text-center vh-50 d-flex flex-column justify-content-center m-5">
    <!-- Cal canviar la frase "Aqui cal fer apareixer el nom d'usuari" pel nom d'usuari logejat -->
    <h1 class="display-3 mb-2">Benvingut: "Aqui cal fer apareixer el nom d'usuari"</h1>
    <img src="../img/05_Cicles_dreta.png" class="rounded mx-auto d-block" alt="...">
</div>


<?php
include('../template/footer.php');
    //Aqui cal carregar la template footer.php
?>