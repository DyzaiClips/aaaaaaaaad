<?php
//en aquesta part del codi cal carregar la template de la navbar

?>

<div class="text-center vh-50 d-flex flex-column justify-content-center m-5">
    <h1 class="display-3 mb-2">My First Exam</h1>
<img src="../img/05_Cicles_dreta.png" class="rounded mx-auto d-block" alt="...">
</div>


<?php
include('../template/navbar_out.php');
include('../template/footer.php');
//Aqui cal carregar la template footer.php
?>