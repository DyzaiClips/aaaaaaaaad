<?php

header('Location: ../view/login_view.php');
//fer la logica del logout i redirigir a la home